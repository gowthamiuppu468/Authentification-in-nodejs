const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const http = require('http');
const app = express();
const fs = require('fs');
const mongoClient = require('mongodb').MongoClient;

//create database

var url = "mongodb://localhost:27017/mydb";
mongoClient.connect(url, function (err, db) {
	if (err) throw err;
	console.log("Database created!");
	db.close();
});

//create collection
mongoClient.connect(url, function (err, db) {
	if (err) throw err;
	var dbo = db.db("mydb");
	dbo.createCollection("students", function (err, res) {
		if (err) throw err;
		console.log("Collection created!");
		db.close();
	});
});



app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

app.get('/', function (request, response) {		//here / is the default route
	fs.readFile("index.html", function (err, data) {
		response.writeHead(200, { 'Content-Type': 'text/html' });
		response.write(data);
		response.end();
	});
});

app.get('/registration', function (request, response) {
	fs.readFile("signUp.html", function (err, data) {
		response.writeHead(200, { 'Content-Type': 'text/html' });
		response.write(data);
		response.end();
	});
});

app.get('/loginpage', function (request, response) {
	fs.readFile("login.html", function (err, data) {
		response.writeHead(200, { 'Content-Type': 'text/html' });
		response.write(data);
		response.end();
	});
});

app.get('/resetPasswordpage', function (request, response) {
	fs.readFile("resetPassword.html", function (err, data) {
		response.writeHead(200, { 'Content-Type': 'text/html' });
		response.write(data);
		response.end();
	});
});

app.get('/forgotPasswordpage', function (request, response) {
	fs.readFile("forgotPassword.html", function (err, data) {
		response.writeHead(200, { 'Content-Type': 'text/html' });
		response.write(data);
		response.end();
	});
});

app.post('/login', function (req, res) {
	var email = req.body.email;
	var password = req.body.pswd;
	console.log("email-->", email);
	console.log("password-->", password);

	mongoClient.connect(url, function (err, db) {
		if (err) throw err;
		var dbo = db.db("mydb");
		var myobj = { "userName": email, "password": password };
		dbo.collection("students").findOne(myobj, function (err, findres) {
			if (err) {
				throw err;
			}
			else {
				if (findres == null) {
					// alert("");
					res.json({ "message": "Please signup first" });
				}
				else {
					res.json({ "message": "successfully logged in" });
					// alert("successfully logged in");
				}
			}
			db.close();
		});
	});
	// add logic here


	//after send responce like this

});


app.post('/signup', function (req, res) {
	var email = req.body.email;
	var password = req.body.pswd;
	var confirmPassword = req.body.cnfmpswd;
	var mobileNo = req.body.mbno;

	console.log("email-->", email);
	console.log("possword-->", password);
	console.log("mobileNo-->", mobileNo);

	mongoClient.connect(url, function (err, db) {
		if (err) throw err;
		var dbo = db.db("mydb");
		var myobj = { "userName": email };
		dbo.collection("students").findOne(myobj, function (err, findres) {
			if (err) { throw err; }
			else {
				// console.log("responce--->",findres);
				if (findres != null) {
					res.json({ "message": "user already registered" });
				}
				else {
					var myobj1 = { "userName": email, "password": password, "confirmPassword": confirmPassword, "mobileNo": mobileNo };
					dbo.collection("students").insertOne(myobj1, function (err, insertres) {
						if (err) throw err;
						console.log("1 document inserted");
					});
				}
			}
			db.close();
			res.json({ "signup": "success" });
		});
	});
});

app.post('/resetPassword', function (req, res) {
	var email = req.body.email;
	var oldPassword = req.body.oldpswd;
	var newPassword = req.body.newpswd;

	console.log("email-->", email);
	console.log("newPassword-->", newPassword);

	mongoClient.connect(url, function (err, db) {
		if (err) throw err;
		var dbo = db.db("mydb");
		var myobj = { "userName": email, "password": oldPassword };
		var newvalues = { $set: { password: newPassword } };
		dbo.collection("students").update(myobj,newvalues,function (err, updateres) {
			// console.log("updateres---->",updateres);
			// console.log("errr---->",err);
			if (err) {
				throw err;
			}
			else {
				// alert("Successfully reset the password");
				res.json({ "resetPassword": "success" });
			}
			db.close();
		});
	});
});

app.post('/forgotPassword', function (req, res) {
	var email = req.body.email;
	mongoClient.connect(url, function (err, db) {
		if (err) throw err;
		var dbo = db.db("mydb");
		var myobj = { "userName": email };
		dbo.collection("students").findOne(myobj, function (err, findres) {
			if (err) {
				throw err;
			}
			else {
				if (findres == null) {
					res.json({ "message": "not registered..please register" });
				}
				else {
					// alert("successfully sent the link");
					res.json({ "message": "successfully sent the link" });
				}
			}
			db.close();
		});
	});
});

const port = process.env.port || 5000;
app.set(port);


const server = http.createServer(app);

server.listen(port, () => console.log(`Magic Happens In Port::${port}`));




